import tkinter as tk
import customtkinter as ctk
from tkinter import filedialog, ttk

class main():
    def __init__(self):
        pass

        self.initialize_main_elements()
        self.initialize_menu_elements()
        self.initialize_coding_space()

        self.app.mainloop()
    
    def initialize_main_elements(self):

        self.window_width, self.window_height = 800, 600

        self.app = ctk.CTk()
        self.app.title("LuaBlox")
        self.app.geometry(f"{self.window_width}x{self.window_height}")
        self.app.minsize(self.window_width, self.window_height)
        self.app.config(bg="#202020")
        self.app.iconbitmap("icon.ico")

    def initialize_menu_elements(self):

        self.menu_bar = ctk.CTkFrame(self.app, height=24)
        self.menu_bar.pack(fill="x", padx=5, pady=5)

        self.save_file_button = ctk.CTkButton(self.menu_bar, text="Save File", command=self.save_file, width=16)
        self.save_file_button.pack(padx=5, pady=5, side="left")

        self.open_file_button = ctk.CTkButton(self.menu_bar, text="Open File", command=self.open_file, width=16)
        self.open_file_button.pack(padx=5, pady=5, side="left")

    def initialize_coding_space(self):

        self.coding_frame = ctk.CTkFrame(self.app)
        self.coding_frame.pack(fill="both", expand=True, padx=5, pady=5)

        self.coding_textbox = tk.Text(self.coding_frame, font=("JetBrains Mono", 12), relief="flat", bg="#2b2b2b", fg="white", insertbackground="white")
        self.coding_textbox.pack(fill="both", expand=True, padx=5, pady=5)

    def open_file(self):
        self.file_path = filedialog.askopenfilename(title="Select File", filetypes=[("Roblox Scripts", "*.lua *.rbxlx *.rbxm")])
        
        if self.file_path:
            with open(self.file_path, "r", encoding="utf-8") as file:
                self.content = file.read()

        self.coding_textbox.delete("1.0", tk.END)
        self.coding_textbox.insert("1.0", self.content)
    
    def save_file(self):
        self.file_path = filedialog.asksaveasfilename(defaultextension=".lua", filetypes=[("Roblox Scripts", "*.lua *.rbxlx *.rbxm")])

        if self.file_path:
            self.content = self.coding_textbox.get("1.0", tk.END)

            with open(self.file_path, "w", encoding="utf-8") as file:
                file.write(self.content)

        print(self.file_path)

if __name__ == "__main__":
    main()